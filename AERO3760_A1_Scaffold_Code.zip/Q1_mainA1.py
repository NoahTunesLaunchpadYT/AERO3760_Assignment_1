# Name:
# SID:
import spacetools
import spacetools.constants as const


def question_1():
    ...  # Your code here


if __name__ == "__main__":
    question_1()