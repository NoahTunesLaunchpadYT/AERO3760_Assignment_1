from . import _util
from . import constants as const

from matplotlib.axes import Axes
from mpl_toolkits.mplot3d import Axes3D
import numpy as np


def plot_orbit_2d(ax: Axes, r: np.ndarray, **kwargs) -> None:
    """Plots an orbit in 2D.

    If the input vectors are 3D, the inertial frame is projected onto the orbital plane.
    This is not the same as plotting in the perifocal frame. To plot in the perifocal frame,
    make sure the the input vectors are already represented in the perifocal frame.

    Args:
        ax (Axes): The matplotlib axes to plot on.
        r (np.ndarray): A (2 x N) or (3 x N) array of position vectors.
    """
    if ax.name != 'rectilinear':
        raise ValueError("Invalid Axes type.")
    if r.shape[0] != 2 and r.shape[0] != 3:
        raise ValueError(f"r must be a (2 x N) or (3 x N) array. Got shape {r.shape}.")
    
    # If r is 3D, find the orbital plane, then project onto it.
    if r.shape[0] == 3:
        n_vec = np.cross(r[:, 0], r[:, 1])  # Vector normal to the orbital plane
        n_vec /= np.linalg.norm(n_vec)

        e_x = np.array([1,0,0])
        e_y = np.array([0,1,0])

        # Project onto the orbital plane, if u is too small use e_y instead.
        u = e_x - np.dot(e_x, n_vec) * n_vec
        if np.linalg.norm(u) < 1e-6:
            u = e_y - np.dot(e_y, n_vec) * n_vec
        
        # Form orthonormal basis
        e1 = u / np.linalg.norm(u)
        e2 = np.cross(n_vec, e1)

        proj_mtx = np.array([e1, e2])       # 2 x 3 projection matrix
        r = proj_mtx @ r                      # Project r onto the orbital plane

        r = r[:2, :]  # Keep only the first two dimensions for 2D plotting

    x, y = r[0, :], r[1, :]

    ax.plot(x, y, **kwargs)

    ax.set_xlabel('X')
    ax.set_ylabel('Y')

    ax.set_aspect('equal')

    if 'label' in kwargs:
        ax.legend()

    return


def plot_orbit_3d(ax: Axes3D, r: np.ndarray, **kwargs) -> None:
    """Plots an orbit in 3D.

    Args:
        ax (Axes3D): The matplotlib 3D axes to plot on.
        r (np.ndarray): A (3 X N) array of (x,y,z) positon vectors

    All matplotlib keyword arguments are accepted.
    """
    if ax.name != '3d':
        raise ValueError("Invalid Axes type. Set ax to a 3DAxes object using projection='3d'.")
    if r.shape[0] != 3:
        raise ValueError(f"r must be a (3 x N) array. Got shape {r.shape}.")
    
    x, y, z = r[0, :], r[1, :], r[2, :]

    ax.plot(x, y, z, **kwargs)

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    if 'label' in kwargs:
        ax.legend()
    
    return


def groundtrack(
    ax: Axes,
    latlon: np.ndarray,
    arrows: bool=True,
    arrow_interval: float=3000.0,
    arrow_kwargs: dict=None,
    **kwargs
) -> None:
    """Plots the ground track of a satellite orbit.

    Args:
        ax (Axes): The matplotlib axes to plot on.
        latlon (np.ndarray): A (2 x N) array of (latitude, longitude) pairs in degrees.
        arrows (bool): If True, plot arrows to indicate direction of travel.
                       Defaults to True.

    All matplotlib keyword arguments are accepted.
    """
    if ax.name != 'rectilinear':
        raise ValueError("Invalid Axes type.")
    
    if latlon.shape[0] != 2:
        raise ValueError(f"latlon must be a (2 x N) array. Got shape {latlon.shape}.")
    
    # Set default arrow properties if not provided
    if arrow_kwargs is None:
        arrow_kwargs = {'lw': 1, 'mutation_scale': 10}
    if 'arrowstyle' not in arrow_kwargs:
        arrow_kwargs['arrowstyle'] = '-|>'

    lat = latlon[0, :]
    lon = latlon[1, :]

    # Insert NaNs in between discontinuous segments
    discontinuities = np.where(np.abs(np.diff(lon)) > 180)[0]

    for idx in discontinuities[::-1]:
        lat = np.insert(lat, idx + 1, np.nan)
        lon = np.insert(lon, idx + 1, np.nan)
    
    # If plot has no lines on it, plot the blue marble image
    if not ax.lines:
        img = _util.get_blue_marble_image()
        ax.imshow(img, extent=(-180, 180, -90, 90), aspect='auto', zorder=-1)
    
    line, = ax.plot(lon, lat, **kwargs)
    
    # Plot arrows
    if arrows:
        arrow_kwargs['color'] = line.get_color()
        R = const.R_EARTH * 1e-3  # Convert to km

        lat_r = np.deg2rad(lat)
        lon_r = np.deg2rad(lon)
        dlat = np.diff(lat_r)
        dlon = np.diff(lon_r)

        # mask out any segment involving a NaN
        mask = ~np.isnan(dlat) & ~np.isnan(dlon)

        a = np.zeros_like(dlat)
        a[mask] = (
            np.sin(dlat[mask] / 2) ** 2
            + np.cos(lat_r[:-1][mask])
            * np.cos(lat_r[1:][mask])
            * np.sin(dlon[mask] / 2) ** 2
        )

        dist = np.zeros_like(dlat)
        dist[mask] = 2 * R * np.arcsin(np.sqrt(a[mask]))

        s = np.concatenate([[0], np.cumsum(dist)])

        # pick arrow positions
        t_arrows = np.arange(arrow_interval, s[-1], arrow_interval)
        arrow_idx = np.searchsorted(s, t_arrows)

        for i in arrow_idx:
            if i >= len(lat) - 1:
                continue
            if np.isnan(lat[i]) or np.isnan(lat[i + 1]):
                continue

            start = (lon[i], lat[i])
            end = (lon[i + 1], lat[i + 1])

            ax.annotate(
                '',
                xy=end,
                xytext=start,
                arrowprops={**arrow_kwargs}
            )

    ax.set_xlabel('Longitude (degrees)')
    ax.set_ylabel('Latitude (degrees)')
    ax.set_xlim(-180, 180)
    ax.set_ylim(-90, 90)

    ax.grid(True, which='both', linestyle='--', linewidth=0.5, alpha=0.5)
    ax.set_xticks(np.arange(-180, 181, 30))
    ax.set_yticks(np.arange(-90, 91, 30))

    if 'label' in kwargs:
        ax.legend()
    
    ax.set_aspect('equal')

    return
    

def azimuth_elevation(
    ax: Axes,
    azel: np.ndarray,
    rstep: float=10.0,
    arrows: bool=True,
    arrow_interval: float=10.0,
    arrow_kwargs: dict | None=None,
    **kwargs
) -> None:
    """Plots the azimuth and elevation of a satellite.

    Args:
        ax (Axes): The matplotlib axes to plot on.
        azel (np.ndarray): A (2 x N) array of (azimuth, elevation) vectors, both in radians.
                        Azimuth must be in radians.
        rstep (float): The radial step size for the radial limits of the plot.
                        Defaults to 10.0.
        arrows (bool): If True, plot arrows to indicate direction of travel. Defaults to True.
        arrow_interval (float): The interval at which to place arrows. Defaults to 10.0.
        arrow_kwargs (dict | None): Additional keyword arguments for the arrow properties.

    All matplotlib keyword arguments are accepted.
    The elevation is converted to degrees internally for plotting.
    """
    if ax.name != 'polar':
        raise ValueError("Invalid Axes type. Set ax to a polar Axes object using subplot_kw={'projection': 'polar'}.")
    if azel.shape[0] != 2:
        raise ValueError(f"azel must be a (2 x N) array. Got shape {azel.shape}.")
    
    azimuth, elevation = azel[0, :], np.rad2deg(azel[1, :])

    min_elevation = min(0.0, np.nanmin(elevation))
    ax.set_rlim(90.0, min_elevation)
    ticks = np.arange(90, min_elevation - rstep, -rstep)
    ax.set_rticks(ticks)

    # compute circular diffs so wrap isn't a large number
    circ_diff = (np.diff(azimuth) + np.pi) % (2*np.pi) - np.pi

    # detect “real” discontinuities: diff suddenly ~5x larger than the previous step
    discontinuities = []
    for i in range(1, len(circ_diff)):
        prev, curr = circ_diff[i-1], circ_diff[i]
        if (not np.isnan(prev) and not np.isnan(curr)
            and abs(curr) > 5 * abs(prev)
            and abs(prev) > 0):
            discontinuities.append(i)

    # insert NaN at each break (iterate in reverse to keep indices valid)
    for idx in reversed(discontinuities):
        azimuth = np.insert(azimuth, idx+1, np.nan)
        elevation = np.insert(elevation, idx+1, np.nan)

    line, = ax.plot(azimuth, elevation, **kwargs)

    # Add arrows
    if arrows:
        if arrow_kwargs is None:
            arrow_kwargs = {'arrowstyle': '-|>', 'lw': 1}
        arrow_kwargs.setdefault('color', line.get_color())

        # work segment-by-segment (between NaNs)
        good = ~np.isnan(azimuth)
        starts = np.where(good & np.concatenate(([True], ~good[:-1])))[0]
        ends   = np.where(good & np.concatenate((~good[1:], [True])))[0]

        for s0, s1 in zip(starts, ends):
            idx = np.arange(s0, s1 + 1)
            az  = azimuth[idx]
            el  = np.deg2rad(elevation[idx])         # convert back to rad

            # --- 3-D unit vectors for great-circle distance ---
            x = np.cos(el) * np.cos(az)
            y = np.cos(el) * np.sin(az)
            z = np.sin(el)
            v = np.column_stack((x, y, z))

            # great-circle step angles in **radians**
            ang = np.arccos(np.clip(np.sum(v[:-1] * v[1:], axis=1), -1.0, 1.0))
            ang[np.isnan(ang)] = 0.0
            s = np.concatenate(([0.0], np.cumsum(np.rad2deg(ang)))) # cumulative distance in degrees

            if s[-1] < arrow_interval:
                continue

            targets = np.arange(arrow_interval, s[-1], arrow_interval)
            hit = np.searchsorted(s, targets)

            for i in hit:
                if i >= len(idx) - 1:                 # safety guard
                    continue
                # draw head along the local segment direction
                ax.annotate(
                    '',
                    xy=(azimuth[idx[i+1]], elevation[idx[i+1]]),
                    xytext=(azimuth[idx[i]],   elevation[idx[i]]),
                    arrowprops=arrow_kwargs,
                    annotation_clip=True
                )

    if 'label' in kwargs:
        ax.legend()
    
    return