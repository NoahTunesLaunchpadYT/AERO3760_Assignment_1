"""
Space-related constants.

All constants are in SI units unless otherwise specified i.e. metres not kilometres.

"""

import datetime as dt
from typing import Final
from scipy.constants import G

__all__ = [
    "M_EARTH", "MU_EARTH", "R_EQAT_EARTH", "R_POLE_EARTH", "R_EARTH",
    "E2_EARTH", "J2_EARTH", "ROT_V_EARTH",
    "J2000", "J2000_ERA", "SIDEREAL_DAY", "SOLAR_DAY", "TU", "VERNAL_EQUINOX",
    "C_ZERO_K", "AU_TO_METRES", "METRES_TO_AU", "c",
]

# Earth constants
M_EARTH: Final[float] = 5.97219e24
"""Mass of Earth [kg]"""

MU_EARTH: Final[float] = G * M_EARTH
"""Gravitational parameter of Earth [m^3/s^2]"""

R_EQAT_EARTH: Final[float] = 6_378_137.0
"""Equatorial radius of Earth [m]"""

R_POLE_EARTH: Final[float] = 6_356_752.0
"""Polar radius of Earth [m]"""

R_EARTH: Final[float] = R_EQAT_EARTH
"""Nominal radius of Earth [m]"""

E2_EARTH: Final[float] = 6.69437999014e-3
"""Earth Ellipsoid eccentricity squared"""

J2_EARTH: Final[float] = 1.082626925638815e-3
"""Earth Second zonal harmonic coefficient"""

ROT_V_EARTH: Final[float] = 7.2921159e-5
"""Rotation rate of Earth [rad/s]"""

# Time constants
J2000: Final[dt.datetime] = dt.datetime(2000, 1, 1, 12, 0, 0)
"""J2000 epoch [UTC]"""

J2000_ERA: Final[float] = 4.894_961_212_723_65
"""Earth rotation angle at J2000 [rad]"""

SIDEREAL_DAY: Final[float] = 86_164.1
"""Sidereal day length [s]"""

SOLAR_DAY: Final[float] = 86_400.0
"""Solar day length [s]"""

VERNAL_EQUINOX: Final[dt.datetime] = dt.datetime(2022, 3, 20, 11, 33, 0)
"""Vernal equinox 2022-03-20 [UTC]"""

# Conversions
C_ZERO_K: Final[float] = 273.15
"""Zero °C in Kelvin [K]"""

AU_TO_METRES: Final[float] = 149_597_870_700.0
"""Astronomical unit to metres [m]"""

METRES_TO_AU: Final[float] = 1.0 / AU_TO_METRES
"""Metres to astronomical unit [AU]"""

c: Final[float] = 299_792_458.0
"""Speed of light in vacuum [m/s]"""

# Add TU constant
TU: Final[float] = (R_EARTH**3 / MU_EARTH)**0.5
"""Time unit (canonical time unit) [s]"""
