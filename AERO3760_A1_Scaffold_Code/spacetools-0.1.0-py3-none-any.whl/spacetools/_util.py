from functools import lru_cache
import matplotlib.pyplot as plt
import os

MAP_ASSET_PATH = os.path.join(os.path.dirname(__file__), 'assets', 'bluemarble.jpg')

@lru_cache(maxsize=1)
def get_blue_marble_image():
    """Returns the path to the Blue Marble image asset."""
    if not os.path.exists(MAP_ASSET_PATH):
        raise FileNotFoundError(f"Blue Marble image not found at {MAP_ASSET_PATH}")
    return plt.imread(MAP_ASSET_PATH)